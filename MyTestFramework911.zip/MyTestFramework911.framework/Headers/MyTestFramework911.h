//
//  MyTestFramework911.h
//  MyTestFramework911
//
//  Created by Bogdan Susla on 12/24/19.
//  Copyright © 2019 Bogdan Susla. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for MyTestFramework911.
FOUNDATION_EXPORT double MyTestFramework911VersionNumber;

//! Project version string for MyTestFramework911.
FOUNDATION_EXPORT const unsigned char MyTestFramework911VersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MyTestFramework911/PublicHeader.h>


